#ifndef __EXTENSIONMARCROS_H__
#define __EXTENSIONMARCROS_H__

#define NS_CC_EXT_BEGIN                     namespace cocos2d { namespace extension {
#define NS_CC_EXT_END                       }}
#define USING_NS_CC_EXT                     using namespace cocos2d::extension


#endif /* __EXTENSIONMARCROS_H__ */

