//
//  CardBox.h
//  tableViewForCocosx
//
//  Created by orix on 25/9/12.
//
//

#ifndef tableViewForCocosx_CardBox_h
#define tableViewForCocosx_CardBox_h

#include "cocos2d.h"

USING_NS_CC;

class CardBox : public CCLayer
{
public:
	virtual bool init();
	
	CREATE_FUNC(CardBox);
	NODE_FUNC(CardBox);
};

#endif
